# Contrato 1.0.0

O contrato completo está em ../assets/openapi.json; compare info.version com /openapi.json da instalação. A URL base inclui /api/v1.

Authorization: Bearer <chave>. A API não usa sessão de navegador, cookies nem CORS para chamadas privadas. HTTPS obrigatório fora do desenvolvimento local. Nunca cole segredos em chats públicos, URLs, analytics ou documentação.

products:write envia lotes; products:read consulta produtos e mudanças; analyses:write cria análises; analyses:read lê status e resultados. Emita analyses:write junto com analyses:read. Chaves somente de leitura são suportadas. Nenhuma chave gerencia membros.

A chave expira inicialmente em 90 dias. Rotação cria nova chave da mesma origem, com sobreposição de até 24 horas. Troque o segredo no conector e revogue o antigo. Revogação bloqueia novas chamadas imediatamente. Nunca contorne 403 alterando IDs: cada recurso é validado contra a loja e recurso alheio retorna 404.

ProductInput exige externalId, sourceVersion, name, purchaseCostCents, salePriceCents e active. externalId é sensível a maiúsculas, tem 1–100 caracteres e não admite espaços externos. name tem 1–200 caracteres. sourceVersion é inteiro positivo seguro JSON. barcode opcional, até 100 caracteres, normaliza ausência para null. sourceUpdatedAt é informativo. Custos 0–100000000; preços 1–100000000.

Envio substitui todos os campos de entrada; não é PATCH. Campos desconhecidos são rejeitados. Custo zero e custo acima da venda geram alertas. Barcode duplicado alerta sem fundir produtos. Atividade false inativa; reativar requer versão nova. Ausência no lote não exclui.

Cenários aceitam discountBps, targetBps e feeBps entre 0 e 9900. Com feeEnabled=false, feeBps deve ser zero. IDs, revisão, origem, datas de servidor e alertas são definidos pelo servidor. Veja os schemas completos em openapi.json.
